<html>
<body>
<form action="success.php" method="get">
    Name: <input type="text" name="name"><br>
    E-mail: <input type="text" name="email"><br>
    Mobile Phn: <input type="text" name="Mobilephn"><br>
    <input type="submit">
</form>
</body>
</html>
