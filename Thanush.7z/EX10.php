<html>
<body>
Welcome <?php echo $_GET["name"]; ?><br>
Your email address is: <?php echo $_GET["email"]; ?><br> Your Mobile number is: ?php echo
$_GET["Mobile-phn"]; ?>
</body>
</html>