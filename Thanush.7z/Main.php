<?php
$con = mysqli_connect('localhost','root','');
if(!$con)
{
echo "Not Connected to server";
}
if (!mysqli_select_db($con,'computer'))
{
echo "Database is not selected";
}
$Name = $_POST['Name'];
$Email = $_POST['Email'];
$Mobile = $_POST['Mobile'];
$Department = $_POST['Department'];
$sql="INSERT INTO student (Name,Email,Mobile,Department) VALUES
('$Name','$Email','$Mobile','$Department')";
if (!mysqli_query($con,$sql))
{
echo "Failed";
}
else
{
echo "Passed";
}
header("refresh:2; url=insert.php");
?>