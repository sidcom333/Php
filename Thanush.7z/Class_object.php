<html>
<head>
<title> Class and Object </title>
</head>
<body>
<?php
echo "<b> This program is done by K.Thanush &emsp; 211191101159</b><br><br>";
class Calculation
{
public $a, $b;
function Sum($x, $y)
{
$this->a=$x;
$this->b=$y;
return $x+$y;
}
function Mul($x, $y)
{
$this->a-$x;
$this->b-$y;
return $x*$y;
}
}
$obj1= new Calculation();
echo "The Sum of (10, 20) is: ". $obj1->Sum(10, 20);
echo "<br>The Multiplication of (10, 2) is: ". $obj1->Mul(10, 2);
?>
</body>
</html>
