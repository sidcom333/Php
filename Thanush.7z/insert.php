<html>
<style>
form,input
{
padding:10px;
margin:10px;
}
</style>
<body>
<title>Insert Data</title>
<form action="Main.php" method="POST">
<input type="text" name="Name" placeholder="Name"><br>
<input type="email" name="Email" placeholder="Email Id"><br>
<input type="mobile" name="Mobile" placeholder="Mobile-number"><br>
<input type="text" name="Department" placeholder="Department"><br>
<input type="submit" name="submit">
</form>
</body>
</html>