<?php
class Book {
public $author;
public $title;
public $pages;
function set_name($name) {
$this->name = $name;
}
function get_name() {
     return $this->name;
}
}
$author = new Book();
$title= new Book(); 
$pages = new Book();
$author->set_name('Author   : Dr.APJ Abdul kalam ');
$title->set_name('title     : Wings of fire ');
$pages->set_name('pages     : 180 ');
echo $author->get_name()."\n";
echo $title->get_name()."\n"; 
echo $pages->get_name()."\n";
?>