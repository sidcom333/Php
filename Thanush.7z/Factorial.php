<html>
<head>
<title> Factorial of a number </title>
</head>
<body>
<?php
echo "<b> This program is done by K.Thanush &emsp; 211191101159<br>";
$num = 6;
function Factorial($num)
{
if ($num>0)
{
$result= $num*Factorial($num-1);
return $result;
}
else
return 1;
}
echo "Factorial of 6 is equal to ".Factorial($num);
?>
</body>
</html>