<html>
<head>
<title> Swapping of Number </title>
</head>
<body>
<?php
echo "<b> This program is done by K.Thanush &emsp; 211191101159<br>";
function Swap($x, $y)
{
$temp=$x;
$x=$y;
$y=$temp;
echo "After Swapping of Number<br>A= $x<br>B= $y";
}
$a=10;
$b=20;
echo "Before Swaping of Number<br>A= $a<br>B= $b<br><br>";
Swap($a, $b)
?>
</body>
</html>