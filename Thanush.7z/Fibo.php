<html>
<head>
<title> Fibonacci Series </title>
</head>
<body>
<?php
echo "<b> This program is done by K.Thanush &emsp; 211191101159<br>";
$a=0;
$b=1;
echo "$a\n";
echo "$b\n";
for($x=2; $x<10;$x++)
{
$c=$a+$b;
$a=$b;
$b=$c;
echo "$c\n";
}
?>
</body>
</html>