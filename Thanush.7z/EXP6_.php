<!DOCTYPE html>
<html>
<head>
<title>Car Selection Form</title>
</head>
<body>
<form method="post">
<label for="model">Choose Car Model:</label><br>
<select id="model" name="model">
<option value="Hyundai Creta">Hyundai Creta</option>
<option value="Hyundai Venue">Hyundai Venue</option>
<option value="Hyundai i20">Hyundai i20</option>
</select><br>
<label for="color">Choose Car Color.</label><br>
<select id="color" name="color">
<option value="red">Red</option>
<option value="blue">Blue</option>
<option value="green">Green</option>
</select><br><br>
<input type="submit" name="submit" value="Submit">
</form>
<?php
if(isset($_POST['submit'])) {
$model = $_POST['model'];
$color = $_POST['color'];
class Vechile {
public $name;
public $color;
public function __construct($name, $color) {
$this->name = $name;
$this->color = $color;
}
public function intro() {
     echo "The car is ($this->name) and the color is ($this->color).";
} }
class hyundai extends Vechile { public function message() {
echo "which car is this?\n";
} }
$hyundai = new Hyundai($model,$color);
$hyundai->message();
$hyundai->intro();
}
?>
</body>
</html>