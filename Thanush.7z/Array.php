<html>
<head>
<title> Array Operation in PHP </title>
</head>
<body>
<?php
echo "<b> This program is done by K.Thanush &emsp; 211191101159<br>";
$fruits=["Apple"=>"$40/kg", "Banana"=>"$60/dozen", "Carrot"=>"$30/kg", "Papaya"=>"$50/kg", "Cherry"=>"$40/pic"];
foreach ($fruits as $key => $value)
{
echo "Fruit Name: <b>$key</b>,&emsp; Price: <b>$value </b><br>";
}
?>
</body>
</html>