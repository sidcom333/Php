<!DOCTYPE html>
<html>
<head>
<style>
tr,td {
border: 1px solid black;
padding:10px;
}
</style>
</head>
<body>
<?php
echo "My table";
echo "<table border='1' cellspacing='0'>"; 
for ($row=1;$row<=10; $row++)
{
for($col=1;$col<=10;$col++) {
$x=$col *$row;
echo "<td>$x</td>\n"; 
}
echo "<tr>\n";
}
echo "</tr>";
echo"</table>";
?>
</body>
</html>